const API_BASE = process.env.REACT_APP_API_BASE || '';


export async function getUserById(id = 1) {
const res = await fetch(`${API_BASE}/api/users/${id}`);
if (!res.ok) {
const text = await res.text();
throw new Error(`Erro ao buscar usuário: ${text}`);
}
return res.json();
}