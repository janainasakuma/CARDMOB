import React, { useEffect, useState } from 'react';
import { getUserById } from '../services/userService';
import './Profile.css';


export default function Profile() {
const [user, setUser] = useState(null);
const [loading, setLoading] = useState(true);
const [error, setError] = useState(null);


useEffect(() => {
getUserById(1)
.then((data) => {
setUser(data);
})
.catch((err) => {
setError(err.message);
})
.finally(() => {
setLoading(false);
});
}, []);


if (loading) {
return <div className="profile-container">Carregando...</div>;
}


if (error) {
return <div className="profile-container error">Erro: {error}</div>;
}


return (
<div className="profile-container">
<h2>Meu Perfil</h2>
<div className="profile-card">
<img
src={user?.avatar || 'https://i.pravatar.cc/150?img=15'}
alt="avatar"
className="profile-avatar"
/>
<div className="profile-info">
<p><strong>Nome:</strong> {user?.name || 'Não informado'}</p>
<p><strong>Email:</strong> {user?.email || 'Não informado'}</p>
<p><strong>ID:</strong> {user?.id}</p>
</div>
</div>
</div>
);
}